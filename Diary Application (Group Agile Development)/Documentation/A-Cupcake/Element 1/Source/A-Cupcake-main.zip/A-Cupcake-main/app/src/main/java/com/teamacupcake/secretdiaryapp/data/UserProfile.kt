package com.teamacupcake.secretdiaryapp.data

data class UserProfile(
    var userId: String ="",
    val username: String="",
    val profilePictureUrl: String=""
)
